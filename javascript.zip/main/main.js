// What is Programming language?
// Programming language is a set of instructions that a computer can understand and execute
// URDU: Programing language 1 hadiyat ka majmouaa hai jo hai computer samjta hai or Usmei run hota

// Programming langauge which has their own compilar and transpiler and which run on client side or
// server side is called Programming language


// programming language wo hai wo k jis k pass compilers and transpilers ho or wo client side ya server
// py run  ho

// typscript basically is a superset of javascript 

// transpiler wo hoty jo hamara code low level pramming language convert krta hai wo transpiler kehlata
// Compiler wo hota ko hamara code ko convert krta hai bhot low level pramming language



// Binanry  010011
// decimal  0101110010


// What is JavaScript?
// JavaScript is a programming language that adds interactivity to websites



// Faizan Sir  kesay ho??
// transpilar kesay ho?
// Compilar  how are you ?


// zeeshan urdu nh ati hai tum sirf english
//  zeehan i'm very well

// transpiler i'm fine 
// compiler mei thek hn 
// Faizan zeeshan ney bola mei thek ho




// console.log("Hello World");

// javascript  datatypes

// no1 Integer  10 100 1000 1000000 120000 130000 
// no2 float   10.6 150.6 1.1
// no3 string   "Faizan"  "100"
// no4 boolean   true false
// no5 object   { } curly braces
// no6 Array    [] square brackets


// three types of keywords
//  var (varable declaration)
//  let (variable declaration)
//  const (constant declaration)  jo chez change ya modification nh krne deta hai

// variables declaration var let const

// var name = "Faizan"; // String
// var age = 20; //Integer
// var height = 5.6; // Float
// var isMarried = true; // Boolean
// var userObj = {}; // Object
// var students = [
//     "Faizan", // 0 index number is start from 0
//     "Ahmed",  // 1
//     "Talha",  // 2
//     "Umair",  // 3
//     "Hafiz",  // 4
//     "Nadeem", // 5
//     10,       // 6
//     1.4,      // 7
//     true,


// ]; // Array is collection of data 


// console.log(students);
// console.log(students[1]);
// console.log(students[2]);
// console.log(students[3]);
// console.log(students[4]);
// console.log(students[5]);


// console.log(" Total number of students ", students.length);



// console.log(name);
// console.log(age);
// console.log(height);
// console.log(isMarried);
// console.log(isMarried);
// console.log(userObj);





// var let const 

// arthematic operators
// + - * / %
//  ( = Assign Operator)     
//   += -= *= /=  %/
//  == === 
// !=   !== 
//  >   <    >=    <=


// let extraNumber = 10;
// let number = 10;



// if(extraNumber === number) {
//     console.log("if Equal");
//     Console.WriteLine("Hello World!"); 

// } else {    
//     console.log("else Not Equal");
// }

// // Hello World! programming language
// console.log("else Not Equal");




// if(extraNumber !== number) {
//     console.log(" if Not Equal");

// } else {
//     console.log("else Equal");
// }












// let number = 20;

// let part = 20;

// // condition
// if (number === part) {
//     console.log("Equal");
// } else {
//     console.log("Not Equal");
// }












// var ===< let const

// let number = 10;
// let numberUrdu = 20;

// const numberEnglish = 30;



// object mei keys or values 
// keys 1 object mei kabhi duplicate nh ho sakti hai
// values ho sakti hain duplicate mgr keys nh ho sakti
// let myNewObj = {
//     user: [
//         { //0
//             name: "Ali",
//             age: 20,
//         },
//         {  //1
//             name: "Ahmed",
//             age: 20,
//         }
//     ],
//     student: {
//         number: 20,
//         exams: "maths"
//     }
// }


// console.log(myNewObj.student);
// console.log(myNewObj.user[1].age);







// let myArray = [
//     {
//         name: "Ali",
//         age: 20,
//         height: 5.6,
//         notMarried: true,
//         fullName: "Ali Ahmed",
//         address: "karachi",
//         country: "Pakistan",
//     },
//     {
//         name: "Ahmed",
//         age: 20,
//         height: 5.6,
//         notMarried: true,
//         fullName: "Ali Ahmed",
//         address: "karachi",
//         country: "Pakistan",
//     },
//     {
//         name: "Talha",
//         age: 20,
//         height: 5.6,
//         notMarried: true,
//         fullName: "Ali Ahmed",
//         address: "karachi",
//         country: "Pakistan",
//     },
//     {
//         name: "Umair",
//         age: 20,
//         height: 5.6,
//         notMarried: true,
//         fullName: "Ali Ahmed",
//         address: "karachi",
//         country: "Pakistan",
//     }
// ]


// let myArray = [
//     "Faizan",
//     "Ahmed",
//     "Talha",
//     "Umair",
//     "Hafiz",
//     "Nadeem",
//     "Umair",
//     "Nadeem",
//     "zeehan",
//     "Muhammad",
// ]

// for(let i=0; i < myArray.length;   i++)  {
//     console.log(myArray[i]);
// }




// for loop mei 3 step hoty hain jo k humne follow krney hoty hain 
// no1 initialization
// no2 condition
// no3 increment or decrement
// no4 Statement


// For Loop 
// For Loop  yeh chala hai Array k upper
// for(
//     let i = 0;  // 1 break
//     i < myArray.length; // bari hai true jb nh hoti to agaye nh jata yeh
//     i++ // plus one value hogai 
// ) {
//     console.log(myArray[i]);
// }


// let myNewObj = {
//     name: "Ali",
//     age: 20,
//     height: 5.6,
//     notMarried: true,
//     fullName: "Ali Ahmed",
//     address: "karachi",
//     country: "Pakistan",
// }


// for(let i = 0; Object.keys(myNewObj).length > i; i++) {

//     // console.log(Object.keys(myNewObj)[i], ":", myNewObj[Object.keys(myNewObj)[i]]);

// }



// // For In Loop  yeh chala hai Object k upper
// for (let key in myNewObj) {
//     console.log("key:", key, "Value:", myNewObj[key]);

// }

// const myTaskArray = [
//     "Talha",
//     "Umair",
//     "Hafiz",
//     "Naeem",
//     "Umair",
//     "Nadeem",
//     "zeehan",
//     "Muhammad",
//     "Hafiz"
// ]


// Task: apny for In loop chalna hai is myTaskArray k Upper




// Events 
// OnClick
// onChange
// Input
// onWindowLoad
// contextmenu

// params (parameters)

let myArray = [
    "nadeem",
    "asim",
    "imran",
    "muneer",
]

function userName(params) {
        
    for (let i = 0; i < myArray.length; i++) {

        if (myArray[i] != params)  {

        }

    }


}









// const userName = () => {

// }


















































































